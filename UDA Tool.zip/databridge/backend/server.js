/**
 * DataBridge AI - Backend Server
 * Node.js + Express + Azure OpenAI
 * Runs on Azure VM, never exposes API keys to frontend
 */

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const xlsx = require("xlsx");
const sql = require("mssql");
const { Pool } = require("pg");
const mysql = require("mysql2/promise");
const { OpenAIClient, AzureKeyCredential } = require("@azure/openai");
const path = require("path");
const fs = require("fs");
const { pipeline } = require("stream");
const { promisify } = require("util");
const pipelineAsync = promisify(pipeline);

const app = express();
const PORT = process.env.PORT || 5000;
const upload = multer({ dest: "uploads/" });

// ─── Middleware ────────────────────────────────────────────────────────────────
app.use(cors({ origin: process.env.FRONTEND_URL || "http://localhost:3000" }));
app.use(express.json({ limit: "10mb" }));

// Serve React build in production
if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "../frontend/build")));
}

// ─── Azure OpenAI Client ───────────────────────────────────────────────────────
const azureClient = new OpenAIClient(
  process.env.AZURE_OPENAI_ENDPOINT,       // e.g. https://your-resource.openai.azure.com
  new AzureKeyCredential(process.env.AZURE_OPENAI_API_KEY)
);
const DEPLOYMENT = process.env.AZURE_OPENAI_DEPLOYMENT || "gpt-4o"; // your deployment name

// ─── In-memory store for uploaded mapping Excel ────────────────────────────────
let trainingMappings = [];

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE: Health check
// ─────────────────────────────────────────────────────────────────────────────
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE: Upload training Excel
// ─────────────────────────────────────────────────────────────────────────────
app.post("/api/upload-mapping", upload.single("file"), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });
    const workbook = xlsx.readFile(req.file.path);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = xlsx.utils.sheet_to_json(sheet);
    trainingMappings = rows;
    fs.unlinkSync(req.file.path);
    res.json({ success: true, rowCount: rows.length, sample: rows.slice(0, 3) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE: Test connection to any source
// ─────────────────────────────────────────────────────────────────────────────
app.post("/api/connect", async (req, res) => {
  const { sourceType, credentials } = req.body;
  try {
    switch (sourceType) {
      case "sqlserver":
      case "azure_sql": {
        const pool = await sql.connect({
          server: credentials.host || credentials.server,
          port: parseInt(credentials.port) || 1433,
          database: credentials.database,
          user: credentials.username,
          password: credentials.password,
          options: { encrypt: true, trustServerCertificate: true },
          connectionTimeout: 8000,
        });
        await pool.request().query("SELECT 1 AS test");
        await pool.close();
        break;
      }
      case "postgres": {
        const pgPool = new Pool({
          host: credentials.host, port: parseInt(credentials.port) || 5432,
          database: credentials.database, user: credentials.username,
          password: credentials.password, connectionTimeoutMillis: 8000,
          ssl: { rejectUnauthorized: false },
        });
        const client = await pgPool.connect();
        await client.query("SELECT 1");
        client.release();
        await pgPool.end();
        break;
      }
      case "mysql": {
        const conn = await mysql.createConnection({
          host: credentials.host, port: parseInt(credentials.port) || 3306,
          database: credentials.database, user: credentials.username,
          password: credentials.password, connectTimeout: 8000,
        });
        await conn.query("SELECT 1");
        await conn.end();
        break;
      }
      default:
        // For cloud sources (Azure Blob, S3, etc.) — validate fields only in this demo
        if (!credentials || Object.keys(credentials).length === 0) {
          return res.status(400).json({ error: "Missing credentials" });
        }
    }
    res.json({ success: true, message: `Connected to ${sourceType} successfully` });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE: Fetch source schema (columns)
// ─────────────────────────────────────────────────────────────────────────────
app.post("/api/schema", async (req, res) => {
  const { sourceType, credentials, tableName } = req.body;
  try {
    let columns = [];
    switch (sourceType) {
      case "sqlserver":
      case "azure_sql": {
        const pool = await sql.connect({
          server: credentials.host || credentials.server,
          port: parseInt(credentials.port) || 1433,
          database: credentials.database,
          user: credentials.username, password: credentials.password,
          options: { encrypt: true, trustServerCertificate: true },
        });
        const result = await pool.request()
          .input("table", sql.NVarChar, tableName)
          .query(`SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE
                  FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @table ORDER BY ORDINAL_POSITION`);
        columns = result.recordset.map(r => ({
          name: r.COLUMN_NAME,
          type: r.DATA_TYPE + (r.CHARACTER_MAXIMUM_LENGTH ? `(${r.CHARACTER_MAXIMUM_LENGTH})` : ""),
          nullable: r.IS_NULLABLE === "YES"
        }));
        await pool.close();
        break;
      }
      case "postgres": {
        const pgPool = new Pool({
          host: credentials.host, port: parseInt(credentials.port) || 5432,
          database: credentials.database, user: credentials.username, password: credentials.password,
          ssl: { rejectUnauthorized: false },
        });
        const client = await pgPool.connect();
        const result = await client.query(
          `SELECT column_name, data_type, character_maximum_length, is_nullable
           FROM information_schema.columns WHERE table_name=$1 ORDER BY ordinal_position`,
          [tableName]
        );
        columns = result.rows.map(r => ({
          name: r.column_name,
          type: r.data_type + (r.character_maximum_length ? `(${r.character_maximum_length})` : ""),
          nullable: r.is_nullable === "YES"
        }));
        client.release(); await pgPool.end();
        break;
      }
      default:
        columns = []; // For non-DB sources, return empty; UI handles manually
    }
    res.json({ success: true, columns });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE: AI Column Mapping via Azure OpenAI
// ─────────────────────────────────────────────────────────────────────────────
app.post("/api/ai-mapping", async (req, res) => {
  const { sourceColumns, targetColumns } = req.body;

  const trainingContext = trainingMappings.length > 0
    ? `\nYou have been trained on these historical mappings:\n${JSON.stringify(trainingMappings.slice(0, 30), null, 2)}\nUse them to improve accuracy.`
    : "";

  const prompt = `You are a senior data integration architect with expertise in ETL pipelines.
${trainingContext}

Map the following source columns to target columns using semantic understanding.

SOURCE COLUMNS: ${JSON.stringify(sourceColumns)}

TARGET COLUMNS (with types and descriptions):
${JSON.stringify(targetColumns, null, 2)}

Return ONLY a valid JSON array. No markdown, no explanation. Format:
[
  {
    "target": "TARGET_COLUMN_NAME",
    "source": "source_column_name_or_null",
    "confidence": "high|medium|low",
    "reason": "brief reason max 10 words",
    "transform": "SQL transform expression or null"
  }
]

Rules:
- Every target column must have an entry
- Use null for source if no reasonable match exists
- high = direct/semantic match, medium = needs transform or partial match, low = guessed
- Transforms must be valid SQL expressions`;

  try {
    const response = await azureClient.getChatCompletions(DEPLOYMENT, [
      { role: "system", content: "You are a data mapping expert. Return only valid JSON." },
      { role: "user", content: prompt }
    ], { maxTokens: 2000, temperature: 0.1 });

    const text = response.choices[0].message.content.replace(/```json|```/g, "").trim();
    const mappings = JSON.parse(text);
    res.json({ success: true, mappings });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE: AI Chat for mapping review
// ─────────────────────────────────────────────────────────────────────────────
app.post("/api/ai-chat", async (req, res) => {
  const { messages, mappings, sourceColumns, targetColumns } = req.body;

  const systemPrompt = `You are DataBridge AI, a data mapping assistant.
Current mappings: ${JSON.stringify(mappings)}
Source columns available: ${JSON.stringify(sourceColumns)}
Target columns: ${JSON.stringify(targetColumns.map(c => c.name))}
Help the user review, understand, and modify mappings. Be concise (max 3 sentences).`;

  try {
    const response = await azureClient.getChatCompletions(DEPLOYMENT, [
      { role: "system", content: systemPrompt },
      ...messages
    ], { maxTokens: 500, temperature: 0.3 });
    res.json({ success: true, reply: response.choices[0].message.content });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE: Extract data and split into text files (SSE streaming)
// ─────────────────────────────────────────────────────────────────────────────
app.post("/api/extract", async (req, res) => {
  const { sourceType, credentials, tableName, mappings, rowsPerFile, outputPrefix, delimiter } = req.body;
  const delim = delimiter || "|";
  const outputDir = path.join(__dirname, "output");
  if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir);

  // SSE setup
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  const send = (msg) => res.write(`data: ${JSON.stringify({ log: msg })}\n\n`);
  const sendFile = (name) => res.write(`data: ${JSON.stringify({ file: name })}\n\n`);
  const done = () => res.write(`data: ${JSON.stringify({ done: true })}\n\n`);

  try {
    send("🔗 Connecting to data source...");

    // Build SELECT with transforms
    const selectClauses = mappings
      .filter(m => m.source)
      .map(m => m.transform ? `${m.transform} AS ${m.target}` : `${m.source} AS ${m.target}`)
      .join(", ");

    const headerRow = mappings.map(m => m.target).join(delim);
    send("📋 Applying column mappings and SQL transforms...");

    let fileIndex = 1;
    let rowsWritten = 0;
    let currentFile = null;
    let currentStream = null;

    const openFile = () => {
      const fname = `${outputPrefix}${String(fileIndex).padStart(3, "0")}.txt`;
      const fpath = path.join(outputDir, fname);
      currentStream = fs.createWriteStream(fpath);
      currentStream.write(headerRow + "\n");
      return fname;
    };

    const closeFile = (fname) => {
      return new Promise(resolve => { currentStream.end(resolve); });
    };

    // SQL Server extraction
    if (sourceType === "sqlserver" || sourceType === "azure_sql") {
      const pool = await sql.connect({
        server: credentials.host || credentials.server,
        port: parseInt(credentials.port) || 1433,
        database: credentials.database,
        user: credentials.username, password: credentials.password,
        options: { encrypt: true, trustServerCertificate: true },
      });

      let fname = openFile();
      send(`📦 Writing ${fname}...`);

      const request = pool.request();
      request.stream = true;
      request.query(`SELECT ${selectClauses} FROM ${tableName}`);

      await new Promise((resolve, reject) => {
        request.on("row", async (row) => {
          const line = mappings.map(m => {
            const v = row[m.target];
            return v === null || v === undefined ? "" : String(v).replace(/[\r\n]/g, " ");
          }).join(delim);
          currentStream.write(line + "\n");
          rowsWritten++;

          if (rowsWritten % rowsPerFile === 0) {
            await closeFile(fname);
            sendFile(fname);
            send(`✅ ${fname} — ${rowsPerFile.toLocaleString()} rows`);
            fileIndex++;
            fname = openFile();
            send(`📦 Writing ${fname}...`);
          }
        });
        request.on("done", async () => {
          await closeFile(fname);
          sendFile(fname);
          send(`✅ ${fname} — ${rowsWritten % rowsPerFile || rowsPerFile} rows`);
          resolve();
        });
        request.on("error", reject);
      });
      await pool.close();

    } else if (sourceType === "postgres") {
      const pgPool = new Pool({
        host: credentials.host, port: parseInt(credentials.port) || 5432,
        database: credentials.database, user: credentials.username, password: credentials.password,
        ssl: { rejectUnauthorized: false },
      });
      const client = await pgPool.connect();
      let fname = openFile();
      send(`📦 Writing ${fname}...`);

      const query = client.query(new (require("pg")).Cursor(`SELECT ${selectClauses} FROM ${tableName}`));
      const readBatch = () => new Promise((res, rej) => query.read(500, (err, rows) => err ? rej(err) : res(rows)));

      let batch;
      while ((batch = await readBatch()) && batch.length > 0) {
        for (const row of batch) {
          const line = mappings.map(m => {
            const v = row[m.target.toLowerCase()];
            return v === null || v === undefined ? "" : String(v).replace(/[\r\n]/g, " ");
          }).join(delim);
          currentStream.write(line + "\n");
          rowsWritten++;
          if (rowsWritten % rowsPerFile === 0) {
            await closeFile(fname); sendFile(fname);
            send(`✅ ${fname} — ${rowsPerFile.toLocaleString()} rows`);
            fileIndex++; fname = openFile();
            send(`📦 Writing ${fname}...`);
          }
        }
      }
      await closeFile(fname); sendFile(fname);
      client.release(); await pgPool.end();
    }

    send(`\n🎉 Extraction complete! ${fileIndex} file(s), ${rowsWritten.toLocaleString()} total rows.`);
    done();
  } catch (err) {
    res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
    done();
  }
  res.end();
});

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE: Download extracted file
// ─────────────────────────────────────────────────────────────────────────────
app.get("/api/download/:filename", (req, res) => {
  const fpath = path.join(__dirname, "output", req.params.filename);
  if (!fs.existsSync(fpath)) return res.status(404).json({ error: "File not found" });
  res.download(fpath);
});

// Catch-all for React in production
if (process.env.NODE_ENV === "production") {
  app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../frontend/build/index.html")));
}

app.listen(PORT, () => console.log(`✅ DataBridge AI server running on port ${PORT}`));
